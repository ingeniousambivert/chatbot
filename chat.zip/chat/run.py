from chatterbot import ChatBot
from chatterbot.trainers import ListTrainer
import pyttsx3
voiceEngine = pyttsx3.init()
voiceEngine.setProperty('rate', 130	)
voiceEngine.setProperty('voice', "en_US")
chatbot = ChatBot('GlsBot',
	logic_adapters=[
        "chatterbot.logic.BestMatch",
		"chatterbot.logic.MathematicalEvaluation"
    ]
)
trainer = ListTrainer(chatbot)
file=open('data.txt', 'r').readlines();
trainer.train('chatterbot.corpus.english')
#trainer.train(file)

while True:
	req=input("Enter:");
	if req=="exit":
		break;
	response = chatbot.get_response(req)
	print(response)
	voiceEngine.say(response)
	voiceEngine.runAndWait()
	
